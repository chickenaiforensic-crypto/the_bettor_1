# Champions League, Europa League - Europe

## What's `football.db`?

A free open public domain football database & schema
for use in any (programming) language e.g. uses datasets in (structured) text
using the football.txt format.
More [`football.db` Project Site »](http://openfootball.github.io)


## Intro

Free open public domain football datasets for Europe.
Intern'l football club tournaments include:

- UEFA Champions League
- UEFA Europa League
- UEFA Conference League

Example:

```
= UEFA Champions League

Group A |  Manchester United  Shakhtar Donetsk     Bayer Leverkusen      Real Sociedad
Group B |  Real Madrid        Juventus             Galatasaray           FC København
Group C |  Benfica Lisboa     Paris Saint-Germain  Olympiacos            RSC Anderlecht
Group D |  Bayern München     CSKA Moskva          Manchester City       Viktoria Plzeň
Group E |  Chelsea FC         FC Schalke 04        FC Basel              Steaua București
Group F |  Arsenal FC         Olympique Marseille  Borussia Dortmund     SSC Napoli
Group G |  FC Porto           Atlético Madrid      Zenit St. Petersburg  Austria Wien
Group H |  FC Barcelona       AC Milan             Ajax Amsterdam        Celtic Glasgow

...

▪ Quarter-finals - 1st Leg
Tue Apr 1
  20:45   FC Barcelona        v Atlético Madrid  1-1      @ Camp Nou, Barcelona
            (Neymar 71'; Diego 56')
          Manchester United    v Bayern München  1-1      @ Old Trafford, Manchester
            (Vidić 58'; Schweinsteiger 67')
Wed Apr 2
  20:45   Real Madrid         v Borussia Dortmund  3-0    @ Santiago Bernabéu, Madrid
            (Bale 3' Isco 27' Ronaldo 57')
         Paris Saint-Germain v Chelsea FC  3-1            @ Parc des Princes, Paris
            (Lavezzi 4' Luiz 61' (o.g.) Pastore 90+3'; Hazard 27' (pen.))

...
```


## Build Your Own `football.db` Database or `football.json/.csv` Datasets

Yes, you can. See the [football.db/.json/.csv How-Tos »](https://github.com/openfootball/quick-starter)




## Questions? Comments?

Yes, you can. More than welcome.
See [Help & Support »](https://github.com/openfootball/help)
